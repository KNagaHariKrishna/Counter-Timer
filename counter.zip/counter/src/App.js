import './App.css';
import CountdownTimer from './Count';

function App() {
  return (
    <div className="App">
      <CountdownTimer/>
    </div>
  );
}

export default App;
